
namespace CadAlunoTorloni.Models
{
    public class Fruta
    {
        //id
        // Nome
        // Cor

        public int Id;
        public string Nome;
        public string Cor;
        public string Categoria;
    }
}